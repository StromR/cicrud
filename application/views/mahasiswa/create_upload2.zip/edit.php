<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Crud CodeIgniter</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css');?>" type="text/css">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css');?>" type="text/css">
	<link rel="stylesheet" href="<?php echo base_url('assets/font-awesome/css/font-awesome.css');?>" type="text/css">
	<script src="<?php echo base_url('assets/js/jquery.min.js');?>" type="text/javascript"></script>
	<script src="<?php echo base_url('assets/js/jquery-migrate.js');?>" type="text/javascript"></script>
	<script src="<?php echo base_url('assets/js/tether.min.js');?>" type="text/javascript"></script>
	<script src="<?php echo base_url('assets/js/bootstrap.min.js');?>" type="text/javascript"></script>

</head>
<body>

	<div id="wrapper">
		<div class="container">
			<h3>Crud Menggunakan Codeigniter </h3>
			<p>By: Aguzrybudy, 28 Oktober 2017 (Sabtu) <a href="<?php echo base_url('mahasiswa');?>" class="btn btn-primary pull-right"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</a></p>

			<div class="grid-layout">
				<form method="post" action="<?php echo base_url('mahasiswa/update');?>">
					  <input type="hidden" name="id" value="<?php echo $m->id;?>">
					  <div class="form-group">
					    <label for="nim">NIM</label>
					    <input type="text" class="form-control" id="nim" aria-describedby="NPMHelp" placeholder="Enter NIM" name="nim" value="<?php echo $m->nim;?>">
					    <?php echo form_error('nim', '<div class="error">', '</div>'); ?>
					  </div>

					  <div class="form-group">
					    <label for="Nama">Nama</label>
					    <input type="text" class="form-control" id="Nama" placeholder="Nama" name="nama" value="<?php echo $m->nama;?>">
					     <?php echo form_error('nama', '<div class="error">', '</div>'); ?>
					  </div>

					  <div class="form-group">
					    <label for="Kelas">Kelas</label>
					    <select class="form-control" id="Kelas" name="kelas">
					      <option value="<?php echo $m->kelas;?>"><?php echo $m->kelas;?></option>
					      <option value="Pagi">Pagi</option>
					      <option value="Siang">Siang</option>
					      <option value="Malam">Malam</option>
					      <option value="Karyawan">Karyawan</option>
					    </select>
					     <?php echo form_error('kelas', '<div class="error">', '</div>'); ?>
					  </div>

					  <div class="form-group">
					    <label for="Jurusan">Jurusan</label>
					    <select class="form-control" id="Jurusan" name="jurusan">
					      <option value="<?php echo $m->jurusan;?>"><?php echo $m->jurusan;?></option>
					      <option value="Manajemen Informatika">Manajemen Informatika</option>
					      <option value="Sitem Informasi">Sitem Informasi</option>
					      <option value="Tehnik Informatika">Tehnik Informatika</option>
					      <option value="Sistem Komputer">Sistem Komputer</option>
					      <option value="Akutansi">Akutansi</option>
					    </select>
					    <?php echo form_error('jurusan', '<div class="error">', '</div>'); ?>
					  </div>

					  <button type="submit" class="btn btn-primary">Submit</button>
					</form>
			</div>

		</div>
	</div>

</body>
</html>